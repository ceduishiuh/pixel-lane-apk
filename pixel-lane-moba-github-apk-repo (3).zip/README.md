# Pixel Lane MOBA — Offline Android APK (GitHub Actions Build)

This repository packages `Pixel_Lane_MOBA.html` (916.4 KB) into a standalone, 100%-offline Android WebView APK using `androidx.webkit.WebViewAssetLoader`.

- **Application ID**: `com.pixellane.moba`
- **Version**: `1.0.0` (code `1`)
- **Orientation**: `sensorLandscape`
- **Permissions**: None (100% offline — no INTERNET permission requested)
- **Min / Target SDK**: Android 24 / 35

---

## Easiest Phone Method (No PC, No Unzipping)

1. Upload `pixel-lane-moba-github-apk-repo.zip` (or just your `.html` game file) to your GitHub repo.
2. Add `.github/workflows/build-apk.yml` to the repo.
3. Wait ~2 minutes, open **Releases**, and tap `pixel-lane-moba-v1.0.0-release.apk` to install on Android.

## Local Android Studio Build (Optional)

Open the unzipped folder in Android Studio (Ladybug or newer) and click **Build → Build Bundle(s) / APK(s) → Build APK(s)**, or run `gradle assembleDebug`.
