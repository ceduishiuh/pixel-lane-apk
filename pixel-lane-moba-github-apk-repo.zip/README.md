# Pixel Lane MOBA — Offline Android APK (GitHub Actions Build)

This repository packages `Pixel_Lane_MOBA.html` (794.7 KB) into a standalone, 100%-offline Android WebView APK using `androidx.webkit.WebViewAssetLoader`.

- **Application ID**: `com.pixellane.moba`
- **Version**: `1.0.0` (code `1`)
- **Orientation**: `sensorLandscape`
- **Permissions**: None (100% offline — no INTERNET permission requested)
- **Min / Target SDK**: Android 24 / 35

---

## Build Your APK on GitHub (Free, No Android Studio Needed)

1. Push all files in this folder (including `.github/workflows/build-apk.yml`) to a GitHub repository.
2. Open the **Actions** tab — **Build Offline Android APK** starts automatically (~2 minutes).
3. Open the **Releases** tab on your repository and tap `pixel-lane-moba-v1.0.0-release.apk` directly on your Android phone to download and install.

## Local Android Studio Build (Optional)

Open this folder in Android Studio (Ladybug or newer) and click **Build → Build Bundle(s) / APK(s) → Build APK(s)**, or run `gradle assembleDebug`.
